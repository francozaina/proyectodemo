
export class Prestamo {
    id
    rol
    Nombre
    Apellido
} 